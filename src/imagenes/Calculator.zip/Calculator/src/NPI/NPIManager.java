/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NPI;

import calculator.Stack;
import calculator.Tokenizer;
import calculator.Util;

/**
 *
 * @author Estudiantes
 */
public class NPIManager {
    static Stack operators;
    static Stack operation;
    static Stack inverse;
    
    public static Stack NPI(String display_text){
        //Tokenizar
        String[] tokens=Tokenizer.tokenice(display_text);
        //Instanciar pilas
        operation=new Stack();
        operators=new Stack();
        inverse=new Stack();
        //recorrer token a token
        for (int i = 0; i < tokens.length; i++) {
            if(Util.isOperator(tokens[i])){
                if(operators.size==0){
                    operators.push(tokens[i]);
                }
            }
            else{
                operation.push(tokens[i]);
            }
        }
    }
    return null;
    
}
