/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator;

/**
 *
 * @author Estudiantes
 */
public class Util {
    static String  operators="+-*/^";
    static int[] val_operator={0,0,1,1,2};
    
    public static boolean isOperator(String token){
        boolean band=false;
        for (int i = 0; i < operators.length(); i++) {
            if((operators.charAt(i)+"").equals(token)){
                band=true;
            }
        }
        return band;
    }
    // a Mayor qué b
    // Exmple a=*, b=+ => *>+
    public static boolean GreaterThan(String a, String b){
        //IndexOf 
        //Obtiene el indice donde está el el elemento
        int ia=operators.indexOf(a);
        int ib=operators.indexOf(b);        
        return val_operator[ia]>val_operator[ib];
    }
}
