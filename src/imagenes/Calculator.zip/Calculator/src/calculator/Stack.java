/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

/**
 *
 * @author Estudiantes
 */
public class Stack {
    private Node root;
    public int size;  
    
    //La sima estará de última
    public void push(String p){
        if(root==null){
            root=new Node(p, null);
            size=1;
            return;
        }
        Node aux=root;
        for (int i = 0; i < size-1; i++) {
            aux=aux.next;
        }
        aux.next=new Node(p, null);
        size++;
        
    }
    
    public String pop(){
        return delete(size-1);
    }
    
    public String peek(){
        return get(size-1);
    }
    
    private String get(int index){
        Node aux=root;
        for (int i = 0; i < index; i++) {
            aux=aux.next;
        }
        return aux.data;
    }
    
    private String delete(int index){
        if(index==0){
            String p=root.data;
            root=root.next;
            size--;
            return p;
        }
        Node aux=root;
        //Para llegar a la posición anterior index-1
        for (int i = 0; i < index-1; i++) {
            aux=aux.next;
        }
        String p=aux.next.data;
        aux.next=aux.next.next;
        size--;
        return p;        
    }
    
}
