/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator;

/**
 *
 * @author Estudiantes
 */
public class Tokenizer {
    //static significa que el miembro es de clase    
    //miembros=>atributo o método
    //Los miembros de clase no necesitan de instancias
    
    static String  operators="+-*/^";
    //
    public static String[] tokenice(String operation){
        //Lengh retorna el número de caracteres en la cadena
        for (int i = 0; i < operators.length(); i++) {
            //ChartAt retorna el caracter en la posición i
            //Replace All remplaza las ocurrencia de la cadena inicial por la cadena final
            operation=operation.replace(operators.charAt(i)+"", "#"+operators.charAt(i)+"#");
        }
        System.out.println(operation);
       
        return operation.split("#");
    }
    
}
